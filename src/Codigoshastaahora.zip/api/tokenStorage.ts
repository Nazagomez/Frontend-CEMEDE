/**
 * Manejo centralizado del token JWT en el navegador.
 * Aislado en su propio módulo para que tanto httpClient como
 * AuthContext lean/escriban del mismo lugar sin duplicar lógica.
 */
const TOKEN_KEY = 'sitec_token'

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY)
}

export function setToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token)
}

export function clearSession(): void {
  localStorage.removeItem(TOKEN_KEY)
}