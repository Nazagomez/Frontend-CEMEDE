import axios, { AxiosError, type InternalAxiosRequestConfig } from 'axios'
import { getToken, clearSession } from '@/api/tokenStorage'

/**
 * Cliente HTTP centralizado.
 * Todas las llamadas a la API del backend (FastAPI en Azure) deben
 * pasar por esta instancia para heredar baseURL, headers y manejo
 * de errores/JWT de forma consistente.
 */
export const httpClient = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Adjunta el token JWT (si existe) a cada request saliente
httpClient.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = getToken()
  if (token) {
    config.headers.set('Authorization', `Bearer ${token}`)
  }
  return config
})

// Callback opcional que AuthContext registra para reaccionar a un 401
// (por ejemplo, redirigir a /login) sin crear una dependencia circular.
let onUnauthorized: (() => void) | null = null
export function registerUnauthorizedHandler(handler: () => void) {
  onUnauthorized = handler
}

httpClient.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    if (error.response?.status === 401) {
      clearSession()
      onUnauthorized?.()
    }
    return Promise.reject(error)
  }
)