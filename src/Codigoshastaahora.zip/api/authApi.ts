import { httpClient } from '@/api/httpClient'
import type { AuthUser, LoginCredentials, LoginResponse } from '@/types/auth'

/** POST /auth/login — autentica y devuelve el token + los datos del usuario */
export async function loginRequest(credentials: LoginCredentials): Promise<LoginResponse> {
  const { data } = await httpClient.post<LoginResponse>('/auth/login', credentials)
  return data
}

/** GET /auth/me — recupera el usuario autenticado a partir del token guardado */
export async function fetchCurrentUser(): Promise<AuthUser> {
  const { data } = await httpClient.get<AuthUser>('/auth/me')
  return data
}