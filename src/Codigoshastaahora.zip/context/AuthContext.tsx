import { createContext, useCallback, useEffect, useMemo, useState, type ReactNode } from 'react'
import { registerUnauthorizedHandler } from '@/api/httpClient'
import { getToken, setToken as persistToken, clearSession } from '@/api/tokenStorage'
import { isTokenValid } from '@/api/jwt'
import { loginRequest, fetchCurrentUser } from '@/api/authApi'
import type { AuthContextValue, AuthUser, LoginCredentials } from '@/types/auth'

export const AuthContext = createContext<AuthContextValue | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null)
  const [token, setTokenState] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  const logout = useCallback(() => {
    clearSession()
    setUser(null)
    setTokenState(null)
  }, [])

  // Al montar: si hay un token guardado y sigue vigente, recupera el
  // usuario real llamando a /auth/me (el token no trae nombre/rol).
  useEffect(() => {
    async function restoreSession() {
      const stored = getToken()
      if (stored && isTokenValid(stored)) {
        try {
          const me = await fetchCurrentUser()
          setTokenState(stored)
          setUser(me)
        } catch {
          clearSession()
        }
      } else if (stored) {
        clearSession()
      }
      setIsLoading(false)
    }
    restoreSession()
  }, [])

  // Si el backend responde 401 en cualquier request, cerramos sesión.
  useEffect(() => {
    registerUnauthorizedHandler(logout)
  }, [logout])

  const login = useCallback(async (credentials: LoginCredentials) => {
    const { access_token, usuario } = await loginRequest(credentials)
    persistToken(access_token)
    setTokenState(access_token)
    setUser(usuario)
  }, [])

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      token,
      isAuthenticated: Boolean(user),
      isLoading,
      login,
      logout,
    }),
    [user, token, isLoading, login, logout]
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}