import { NavLink, Outlet } from 'react-router-dom'
import { Waves, LayoutDashboard, Users, FileWarning, TrendingUp, MapPin, Bell, LogOut } from 'lucide-react'
import { useAuth } from '@/hooks/useAuth'

const navItems = [
  { to: '/admin/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/admin/visitantes', label: 'Visitantes', icon: Users },
  { to: '/admin/eventos', label: 'Eventos ambientales', icon: FileWarning },
  { to: '/admin/capacidad', label: 'Capacidad de Carga', icon: TrendingUp },
  { to: '/admin/playas', label: 'Playas monitoreadas', icon: MapPin },
  { to: '/admin/notificaciones', label: 'Notificaciones', icon: Bell },
]

const navItemClass = ({ isActive }: { isActive: boolean }) =>
  `flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
    isActive ? 'bg-white/10 text-white' : 'text-white/70 hover:bg-white/5 hover:text-white'
  }`

export function AdminLayout() {
  const { user, logout } = useAuth()

  return (
    <div className="flex min-h-screen">
      <aside className="flex w-60 shrink-0 flex-col bg-navy-900 px-3 py-4">
        <div className="flex items-center gap-2 px-2 pb-6">
          <div className="flex h-9 w-9 items-center justify-center rounded-md bg-white/10">
            <Waves className="h-5 w-5 text-white" strokeWidth={2.25} aria-hidden />
          </div>
          <div className="leading-tight">
            <p className="text-sm font-semibold text-white">SITEC</p>
            <p className="text-[10px] text-white/60">Panel investigador</p>
          </div>
        </div>

        <nav className="flex flex-1 flex-col gap-1" aria-label="Panel admin">
          {navItems.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} className={navItemClass}>
              <Icon className="h-4 w-4" aria-hidden />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="mt-4 border-t border-white/10 pt-4">
          <p className="truncate px-2 text-sm font-medium text-white">{user?.nombre}</p>
          <p className="px-2 text-xs capitalize text-white/50">{user?.rol}</p>
          <button
            onClick={logout}
            className="mt-2 flex w-full items-center gap-2 rounded-md px-2 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-white"
          >
            <LogOut className="h-4 w-4" aria-hidden />
            Cerrar sesión
          </button>
        </div>
      </aside>

      <main className="flex-1 bg-gray-50 px-8 py-8">
        <Outlet />
      </main>
    </div>
  )
}