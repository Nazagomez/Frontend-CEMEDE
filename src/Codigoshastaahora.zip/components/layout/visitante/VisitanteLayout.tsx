import { NavLink, Link, Outlet } from 'react-router-dom'
import { Waves, Home, Activity, TrendingUp, FileWarning, LogOut } from 'lucide-react'

const navItemClass = ({ isActive }: { isActive: boolean }) =>
  `flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-medium transition-colors ${
    isActive ? 'bg-navy-900 text-white' : 'text-ink-700 hover:bg-gray-100'
  }`

export function VisitanteLayout() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="border-b border-gray-200 bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-md bg-navy-900">
              <Waves className="h-5 w-5 text-white" strokeWidth={2.25} aria-hidden />
            </div>
            <div className="leading-tight">
              <p className="text-sm font-semibold text-navy-900">SITEC</p>
              <p className="text-[10px] text-ink-500">Turismo ecológico</p>
            </div>
          </div>

          <nav className="hidden items-center gap-1 md:flex" aria-label="Visitante">
            <NavLink to="/visitante" end className={navItemClass}>
              <Home className="h-4 w-4" aria-hidden />
              Inicio
            </NavLink>
            <NavLink to="/visitante/ocupacion" className={navItemClass}>
              <Activity className="h-4 w-4" aria-hidden />
              Ocupación
            </NavLink>
            <NavLink to="/visitante/capacidad" className={navItemClass}>
              <TrendingUp className="h-4 w-4" aria-hidden />
              Capacidad de carga
            </NavLink>
            <NavLink to="/visitante/eventos" className={navItemClass}>
              <FileWarning className="h-4 w-4" aria-hidden />
              Eventos ambientales
            </NavLink>
          </nav>

          <div className="flex items-center gap-4 text-sm">
            <span className="text-ink-500">Visitante</span>
            <Link to="/" className="flex items-center gap-1 font-medium text-ink-700 hover:text-navy-900">
              <LogOut className="h-4 w-4" aria-hidden />
              Salir
            </Link>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-8">
        <Outlet />
      </main>
    </div>
  )
}