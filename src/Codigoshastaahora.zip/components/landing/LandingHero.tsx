import { Link } from 'react-router-dom'

export function LandingHero() {
  return (
    <section className="px-6 py-20 text-center">
      <h1 className="mx-auto max-w-2xl text-3xl font-semibold text-navy-900 sm:text-4xl">
        Sistema de Información para la Estimación de Capacidad Turística
      </h1>
      <p className="mx-auto mt-4 max-w-xl text-sm text-ink-500">
        Monitorea la ocupación y capacidad turística en Playa Junquillal y Playa Grande
        para apoyar un turismo más sostenible.
      </p>
      <div className="mt-8 flex items-center justify-center gap-3">
        <Link
          to="/visitante"
          className="rounded-md bg-navy-900 px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-navy-800"
        >
          Continuar como visitante
        </Link>
        <Link
          to="/login"
          className="rounded-md border border-navy-900 px-5 py-2.5 text-sm font-medium text-navy-900 transition-colors hover:bg-navy-900 hover:text-white"
        >
          Acceso investigador
        </Link>
      </div>
    </section>
  )
}