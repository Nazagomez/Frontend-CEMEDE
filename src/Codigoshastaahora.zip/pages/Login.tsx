import { useState, type FormEvent } from 'react'
import { Link, Navigate, useLocation } from 'react-router-dom'
import { Waves, Mail, Lock, Eye, EyeOff, ArrowRight } from 'lucide-react'
import { useAuth } from '@/hooks/useAuth'

export function Login() {
  const { login, isAuthenticated } = useAuth()
  const location = useLocation()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  if (isAuthenticated) {
    const redirectTo = (location.state as { from?: Location })?.from?.pathname ?? '/'
    return <Navigate to={redirectTo} replace />
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    setSubmitting(true)
    try {
      await login({ email, password })
    } catch {
      setError('Correo o contraseña incorrectos.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-navy-950 px-4 py-12">
      {/* Fondo con profundidad: blobs difuminados en los tonos de marca */}
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute -top-32 -left-24 h-96 w-96 rounded-full bg-navy-700/40 blur-3xl" />
        <div className="absolute -right-24 top-1/3 h-96 w-96 rounded-full bg-navy-600/30 blur-3xl" />
        <div className="absolute bottom-0 left-1/3 h-72 w-72 rounded-full bg-alert-600/10 blur-3xl" />
      </div>

      {/* Tarjeta */}
      <div className="relative z-10 w-full max-w-md rounded-2xl bg-white p-8 shadow-2xl shadow-black/40 sm:p-10">
        <div className="mb-8 flex flex-col items-center text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-navy-900">
            <Waves className="h-6 w-6 text-white" strokeWidth={2.25} aria-hidden />
          </div>
          <h1 className="mt-4 text-xl font-semibold text-navy-900">SITEC</h1>
          <p className="mt-1 max-w-[280px] text-sm text-ink-500">
            Sistema de Información para la Estimación de Capacidad Turística
          </p>
        </div>

        <p className="mb-5 text-sm font-medium text-ink-700">Acceso investigador</p>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label htmlFor="email" className="text-sm font-medium text-ink-700">
              Correo electrónico
            </label>
            <div className="relative">
              <Mail
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-500"
                aria-hidden
              />
              <input
                id="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-lg border border-gray-300 py-2.5 pl-9 pr-3 text-sm text-ink-900 outline-none transition-colors focus:border-navy-700 focus:ring-2 focus:ring-navy-700/10"
                autoComplete="email"
              />
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="password" className="text-sm font-medium text-ink-700">
              Contraseña
            </label>
            <div className="relative">
              <Lock
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-500"
                aria-hidden
              />
              <input
                id="password"
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-lg border border-gray-300 py-2.5 pl-9 pr-9 text-sm text-ink-900 outline-none transition-colors focus:border-navy-700 focus:ring-2 focus:ring-navy-700/10"
                autoComplete="current-password"
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-500 hover:text-ink-700"
                aria-label={showPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <div className="flex justify-end">
            <button type="button" className="text-sm text-navy-700 hover:underline">
              ¿Olvidaste tu contraseña?
            </button>
          </div>

          {error && (
            <p role="alert" className="text-sm text-alert-600">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="mt-1 flex items-center justify-center gap-1.5 rounded-lg bg-navy-900 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-navy-800 disabled:opacity-50"
          >
            {submitting ? 'Ingresando…' : 'Iniciar sesión'}
            {!submitting && <ArrowRight className="h-4 w-4" aria-hidden />}
          </button>
        </form>

        <div className="my-6 flex items-center gap-3">
          <span className="h-px flex-1 bg-gray-200" />
          <span className="text-xs text-ink-500">o</span>
          <span className="h-px flex-1 bg-gray-200" />
        </div>

        {/* Los visitantes no inician sesión: van directo a sus páginas públicas */}
        <Link
          to="/visitante"
          className="flex w-full items-center justify-center rounded-lg border border-navy-900 px-4 py-2.5 text-sm font-medium text-navy-900 transition-colors hover:bg-navy-900 hover:text-white"
        >
          Continuar como visitante
        </Link>
      </div>
    </div>
  )
}