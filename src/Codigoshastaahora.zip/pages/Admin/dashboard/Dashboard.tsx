import { useAuth } from '@/hooks/useAuth'

export function Dashboard() {
  const { user } = useAuth()

  return (
    <div>
      <h1 className="text-xl font-semibold text-navy-900">Bienvenido, {user?.nombre}</h1>
      <p className="text-sm text-ink-500 capitalize">Rol: {user?.rol}</p>
    </div>
  )
}