import { useContext } from 'react'
import { AuthContext } from '@/context/AuthContext'
import type { AuthContextValue } from '@/types/auth'

/** Acceso tipado al AuthContext. Lanza error si se usa fuera del AuthProvider. */
export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext)
  if (!ctx) {
    throw new Error('useAuth debe usarse dentro de un <AuthProvider>')
  }
  return ctx
}